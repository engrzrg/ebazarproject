<form id="register-form" action="{{route('register')}}" method="post" role="form" style="display: none;">
   {{csrf_field()}}
    <div class="form-group">
        <input id="name" type="text" class="form-control" placeholder="User Name" name="name" value="{{ old('name') }}" required autofocus>

        @if ($errors->has('name'))
            <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
        @endif
    </div>
    <div class="form-group">
        <input id="email" type="email" class="form-control" placeholder="Email Address"   name="email" value="{{ old('email') }}" required>

        @if ($errors->has('email'))
            <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
        @endif </div>
    <div class="form-group">
        <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>

        @if ($errors->has('password'))
            <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
        @endif
    </div>
    <div class="form-group">
        <input id="password-confirm" type="password" class="form-control" placeholder="Confirm Password " name="password_confirmation" required>
    </div>
    <div class="form-group">
        <div class="row">
            <div class="col-sm-6 col-sm-offset-3">
                <input type="submit" id="register-submit" tabindex="4" class="form-control btn btn-register" value="Register Now">
            </div>
        </div>
    </div>
</form>
