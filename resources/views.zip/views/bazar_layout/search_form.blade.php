<div class="row my-search">

        <form>
            <div class="input-group col-md-4 col-md-offset-4">
                <input type="text" class="form-control" placeholder="Search">
                <div class="input-group-btn my-search-btn">
                    <button class="btn btn-default " type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                </div>
            </div>
        </form>

</div>