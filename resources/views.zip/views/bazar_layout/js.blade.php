{{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>--}}
{{--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>--}}
{{--<script src="{{asset('bazar/js/bootstrap.js')}}"></script>--}}

<script>

//paste this code under the head tag or in a separate js file.
// Wait for window load
$(window).on('load',function() {
// Animate loader off screen
$(".se-pre-con").fadeOut("slow");
});
</script>
