<div class="row text-center " style="margin-top: 30px">
    <p>Copyright © 2017 example.cz, a.s.</p>
    <p>The <span class="fa fa-star-o"></span> symbol is marked with advertisements that users have paid <a href="#">More information</a> .</p>
    <p>
        <a href="{{url('/')}}">Home</a>-
        <a href="#">About us</a>-
        <a href="#">Contact</a>-
        <a href="#">Terms $ Conditions</a>
    </p>
</div>