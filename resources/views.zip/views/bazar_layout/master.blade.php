<!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>S Bazar</title>

@include('bazar_layout.css')
    @yield('css')
    <style>
        .no-js #loader { display: none;  }
        .js #loader { display: block; position: absolute; left: 100px; top: 0; }
        .se-pre-con {
            position: fixed;
            left: 0px;
            top: 0px;
            width: 100%;
            height: 100%;
            z-index: 9999;
            background: url(bazar/images/pre_loader/preloader.gif) center no-repeat #fff;
        }
    </style>
</head>
<body>
<div class="se-pre-con"></div>
<div class="container-fluid">


@include('bazar_layout.header')

@yield('body')

@include('bazar_layout.footer')
</div>


@include('bazar_layout.js')
@yield('js')
</body>
</html>
