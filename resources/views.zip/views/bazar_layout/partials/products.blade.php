<div class="row my-products-list">


    <div class="col-lg-3 col-md-4  col-sm-6">
        <div class="my-star"> <span class="fa fa-star-o fa-2x"></span></div>
        <div class="my-products" >

            <a href="{{route('show')}}">
                <div class="thumbnail img-responsive">
                    <img src="http://cdn.pocket-lint.com/r/s/970x/assets/images/138642-laptops-review-acer-swift-7-review-image1-Zq24pc6YCG.jpg" class="img-responsive" alt="karahi">
                </div>
                <div>
                    <span class="product-price "><strong>$23,00</strong></span>
                    <span class="product-category text-danger">Kdyre</span>
                </div>
                <div class="cat-description">
                    Prodám krásný, párkrát vzatý, značkový k  vel. 38. V top stavu!! Pošta 100 Kč. bátek Desigual
                </div>
            </a>
        </div>

    </div>
    <div class="col-lg-3 col-md-4  col-sm-6">
        <div class="my-star"> </div>
        <div class="my-products" >
            <a href="{{route('show')}}">
                <div class="thumbnail img-responsive">
                    <img src="{{asset('bazar/images/mango.jpg')}}" alt="mango">
                </div>
                <div>
                    <span class="product-price "><strong>$23,00</strong></span>
                    <span class="product-category text-danger">Kdyre</span>
                </div>
                <div class="cat-description">
                    Prodám krásný, párkrát vzatý, značkový k  vel. 38. V top stavu!! Pošta 100 Kč. bátek Desigual
                </div>
            </a>
        </div>

    </div>
    <div class="col-lg-3 col-md-4  col-sm-6">
        <div class="my-star"> <span class="fa fa-star-o fa-2x"></span></div>
        <div class="my-products" >
            <a href="{{route('show')}}">
                <div class="thumbnail img-responsive">
                    <img src="https://img.sbazar.cz/big/201710/2509/66/59f0535c66238c8764210100.jpg" alt="">
                </div>
                <div>
                    <span class="product-price "><strong>$23,00</strong></span>
                    <span class="product-category text-danger">Kdyre</span>
                </div>
                <div class="cat-description">
                    Prodám krásný, párkrát vzatý, značkový k  vel. 38. V top stavu!! Pošta 100 Kč. bátek Desigual
                </div>
            </a>
        </div>

    </div>
    <div class="col-lg-3 col-md-4  col-sm-6">
        <div class="my-star"> <span class="fa fa-star-o fa-2x"></span></div>
        <div class="my-products" >

            <a href="{{route('show')}}">
                <div class="thumbnail img-responsive">
                    <img src="https://i.pinimg.com/736x/dc/0a/2e/dc0a2e442730327214c2ef0ee2b13c6b.jpg" class="img-rounded" alt="">
                </div>
                <div>
                    <span class="product-price "><strong>$23,00</strong></span>
                    <span class="product-category text-danger">Kdyre</span>
                </div>
                <div class="cat-description">
                    Prodám krásný, párkrát vzatý, značkový k  vel. 38. V top stavu!! Pošta 100 Kč. bátek Desigual
                </div>
            </a>
        </div>

    </div>
    <div class="col-lg-3 col-md-4  col-sm-6">
        <div class="my-star"> </div>
        <div class="my-products" >
            <a href="{{route('show')}}">
                <div class="thumbnail img-responsive">
                    <img src="https://media.zigcdn.com/media/content/2016/Jul/2016-bmw-i8-zigwheels-india-photo-galary-m1_720x540.jpg" alt="">
                </div>
                <div>
                    <span class="product-price "><strong>$23,00</strong></span>
                    <span class="product-category text-danger">Kdyre</span>
                </div>
                <div class="cat-description">
                    Prodám krásný, párkrát vzatý, značkový k  vel. 38. V top stavu!! Pošta 100 Kč. bátek Desigual
                </div>
            </a>
        </div>

    </div>
    <div class="col-lg-3 col-md-4  col-sm-6">
        <div class="my-star"> <span class="fa fa-star-o fa-2x"></span></div>
        <div class="my-products" >
            <a href="{{route('show')}}">
                <div class="thumbnail img-responsive">
                    <img src="http://images.car.bauercdn.com/pagefiles/31705/1752x1168/bmw-001.jpg?mode=max&quality=90&scale=down" class="img-rounded"  alt="">
                </div>
                <div>
                    <span class="product-price "><strong>$23,00</strong></span>
                    <span class="product-category text-danger">Kdyre</span>
                </div>
                <div class="cat-description">
                    Prodám krásný, párkrát vzatý, značkový k  vel. 38. V top stavu!! Pošta 100 Kč. bátek Desigual
                </div>
            </a>
        </div>

    </div>


</div>
