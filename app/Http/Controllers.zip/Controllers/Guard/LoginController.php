<?php

namespace App\Http\Controllers\Guard;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterNewCustomerRequest;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function index()
    {
        return view('guard.index');
    }
    public function register(RegisterNewCustomerRequest $request)
    {
        $request->register($request->all());
        flash('Your Are register Successfully')->success();
        return back();
    }
    public function login(LoginRequest $request)
    {
        $request->verify($request->all());
        return redirect()->route('listing.create');
    }
}
